/* SPDX-License-Identifier: LGPL-2.1-or-later
 * SPDX-FileCopyrightText: 2024 libgsni contributors
 */

#ifndef GSNI_VERSION_H
#define GSNI_VERSION_H

#define GSNI_MAJOR_VERSION (1)
#define GSNI_MINOR_VERSION (0)
#define GSNI_MICRO_VERSION (0)
#define GSNI_VERSION        ""1.0.0""

#endif /* GSNI_VERSION_H */
